

"""
 Pega as versões de cada pacote, seja
python ou rust, à cada 5min.
"""

# biblioteca padrão:
from datetime import datetime, timedelta
from math import floor, ceil
from random import randint
from shutil import rmtree
from os.path import join as Join, exists
from sys import platform
from os import getenv, remove
# biblioteca externa:
from obtencao import baixa
from gerenciador import CORE_PYTHON as RAIZ


# ritmo de busca das versões.
if __debug__:
   RITIMO = timedelta(seconds=15)
else:
   RITIMO = timedelta(minutes=8)
# como é um alternativo ao existente, mudamos
# temporiariamente o redirecionamento de 
# gravura/leitura.
CORE = "novo-pacotes/data"
# nome do arquivo contendo última registro.
ULTIMO_REGISTRO = Join(RAIZ, CORE, "ultima_busca.dat")
# nome do arquivo que guarda info da última
# varredura.
CONDENSADO_RUST = Join(RAIZ, CORE, "dados_condensados_rust.txt")
CONDENSADO_PYTHON = Join(RAIZ, CORE, "dados_condensados_python.txt")


# salva 'datetime' em disco.
def grava(dt) -> None:
   selo = dt.timestamp()
   # parte-inteira.
   pI = floor(selo)
   # cada parte filtrada.
   (inteiro, decimal) = (pI, selo - pI)

   if __debug__:
      # talvez aceitar-se perder a presição de
      # milisegundos.
      transformacao = ceil(decimal * 10 ** 6)
      print("\nselo = %f(%0.6i)" % (selo, transformacao))
      print("inteiro=%i\tdecimal=%f\n" % (inteiro, decimal))
   ...

   # transforma o decimal em inteiro, apenas
   # para guardar seus bytes. Perde a precisão
   # de milisegundos no processo.
   decimais = int(decimal * (10 ** 6))

   # primeiro grava a parte inteira, e
   # depois a parte decimal.
   with open(ULTIMO_REGISTRO, mode="w+b") as arquivo:
      # valor em 1bi, então quatro bytes é o suficiente:
      bytes = inteiro.to_bytes(4, byteorder="big")
      arquivo.write(bytes)
      # também 4 bytes:
      bytes = decimais.to_bytes(4, byteorder="big")
      arquivo.write(bytes)
   ...
...

# recupera do disco.
def carrega() -> datetime:
   with open(ULTIMO_REGISTRO, "r+b") as arquivo:
      # primeiro 4 bytes da parte inteira.
      string_bytes = arquivo.read(4)
      inteiro = int.from_bytes(string_bytes, byteorder="big")
      # os 4 últimos bytes da parte decimal.
      bytes = arquivo.read(4)
      decimal = int.from_bytes(bytes, byteorder="big")

      # transformando a parte decimal em...
      # bem, decimal, ora!
      decimal = decimal / (10 ** 6)

      # visualizando construção.
      if __debug__:
         print(
            """strBytes='{}'
            \rinteiro={}
            \rdecimal={}
            """
            .format(
               string_bytes, 
               inteiro,
               decimal
            )
         )
      ...

      # convertendo para o tipo 'datetime'
      # novamente, já que é fácil recriar
      # o valor ejetado pela função 'timstamp'
      selo = inteiro + decimal
      return datetime.fromtimestamp(selo)
...

def inverte_iterador(iterador):
   pilha = []

   for item in iterador:
      pilha.append(item)

   while len(pilha) > 0:
      yield(pilha.pop())
...

# extrai de um arquivo com versões, que
# foram extraídas recentementes.
def ve_antigo_registro(chave):
   # vendo último update no banco.
   ultima_atualizacao = carrega()
   agora = datetime.today()
   transcorrido = agora - ultima_atualizacao

   if transcorrido < RITIMO:
      # apenas mostra tempo restante.
      print(
         "faltam {:^0.7s} para nova atualização."
         .format(str(RITIMO - transcorrido))
      )
      # repositório com última versão registrada.
      with open(CONDENSADO, "rt") as arquivo:
         for linha in inverte_iterador(arquivo):
            # se não contém "::" é inválido.      
            if "::" not in linha:
               continue
            (ch, _, versao) = tuple(linha.split("::"))
            if ch == chave:
               return versao[1:].rstrip("\n")
         ...
      ...
   else:
      grava(agora)
      # delete o arquivo para uma atualização.
      print(
         "this file is empty", 
         file = open(CONDENSADO, "wt")
      )
   ...

   # chave, possivelmente nova, então sem dado.
   return None;
...

# extrai versão após fazer o download do arquivo.
# Ela é tirada do arquivo 'Toml', portanto,
# tal método(função) apenas funciona com pacotes
# de 'Rust'.
def extrai_versao(chave, mapa) -> str:
   # lê arquivo já pronto.
   versao = ve_antigo_registro(chave)
   if versao is not None:
      return versao

   # faz o processo todo de download e 
   # extração do arquivo 'Toml'.
   caminho = baixa(chave, mapa)
   # arquivo 'Toml', apenas diretórios com
   # código Rust terão.
   novo_caminho = Join(caminho, "Cargo.toml")

   with open(novo_caminho, "rt") as arquivo:
      for linha in arquivo:
         # se achar linha, pega o conteúdo
         # após o símbolo de igualdade.
         if linha.startswith("version"):
            trecho = linha.split("=")[1]
            trecho = trecho.strip("\"\n ")
            arquivo.close()
            # deleta diretório(irrelevante agora)
            rmtree(caminho, ignore_errors=True)
            return trecho
         ...
      ...
   ...

   # deleta diretório(irrelevante agora)
   rmtree(caminho, ignore_errors=True)
   return None
...

# grava um registro de pacote no banco, para que 
# seja facilmente acessado, sem precisar baixar
# o pacote, e extrair metadados toda vez.
def grava_pacote_registro(linguagem: str, 
cabecalho: str, link: str, versao) -> None:
   if linguagem == "python":
      arquivo = open(CONDENSADO_PYTHON, "wt", encoding="latin1")
      arquivo.write(cabecalho)
      arquivo.write("::")
      arquivo.write(link)
      arquivo.write('\n')
   elif linguagem == "rust":
      arquivo = open(CONDENSADO_RUST, "wt", encoding="latin1")
      arquivo.write(cabecalho)
      arquivo.write("::")
      arquivo.write(link)
      arquivo.write("::")
      arquivo.write(versao)
      arquivo.write('\n')
   else:
      raise Exception("linguagem desconhecida")
   arquivo.close()
...
def le_pacote_registro(linguagem: str, cabecalho: str):
   # abre arquivo específico dependendo da linguagem.
   if linguagem == "python":
      assert exists(CONDENSADO_PYTHON)
      arquivo = open(CONDENSADO_PYTHON, "rt", encoding="latin1")
   elif linguagem == "rust":
      assert exists(CONDENSADO_RUST)
      arquivo = open(CONDENSADO_RUST, "rt", encoding="latin1")
   else:
      raise Exception("linguagem desconhecida")
   for linha in inverte_iterador(iter(arquivo)):
      if linha.startswith(cabecalho):
         partes = linha.split("::")
         try:
            c = next(partes)
            l = next(partes)
            v = next(partes)
         except StopIteration:
            v = None
         arquivo.close()
         return (c, l, v)
      ...
   ...
   arquivo.close()
   # se chegar aqui não foi achado, então não
   # é um dado válido.
...

__all__ = [
   "grava", "carrega", 
   "grava_pacote_registro", 
   "le_pacote_registro"
]

from time import sleep
from unittest import main, TestCase

class Funcoes(TestCase):
   def registroDoDatetime(self):
      atual = datetime.today()
      grava(atual)
      sleep(5.0)
      atual = datetime.today() 
      decorrido = atual - carrega()
      print(decorrido)
      self.assertEqual(decorrido.seconds, 5.0)
   ...
   def registroPacoteMetadados(self):
      import os.path, sys
      print(os.path.abspath(sys.argv[1]))
      pass
...

if __name__ == "__main__":
   main(verbosity=0)

