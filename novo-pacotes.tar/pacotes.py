#!/usr/bin/python3 -O
"""
Programa em sí que baixa os pacotes
e arruma no atual diretório. Também
é possível selecionar o arquivo
específico a extrair.
"""

# deste programa:
#from gerenciador import carrega, mapa, listagem, carrega_rust
#from obtencao import baixa
from gerenciador import (
   carrega, listagem,
   listagemI, CORE_PYTHON
)
from banco_de_dados import (atualiza_bd, grava_pacote_registro)
from obtencao import baixa_e_metadados as baixa

# biblioteca externa:
from python_utilitarios.utilitarios import arvore
GalhoTipo = arvore.GalhoTipo
arvore = arvore.arvore

# biblioteca padrão do Python:
from sys import argv, platform
from time import sleep
from os.path import (basename, exists, join)
from shutil import (rmtree, move)
from os import chmod
from stat import (S_IRWXU, S_IXGRP, S_IXOTH)
from argparse import (ArgumentParser, SUPPRESS)

# colocando permisões:
try:
   chmod("pacotes.py", S_IRWXU | S_IXGRP | S_IXOTH)
except FileNotFoundError:
   caminho = join(CORE_PYTHON, "novo-pacotes/pacotes.py")
   chmod(caminho, S_IRWXU | S_IXGRP | S_IXOTH)
...

menu = ArgumentParser(
   description = """
   baixa pacotes Python ou Rust, diretos do GitHub,
   extraindo-os, e até substituindo os mesmos se já
   houver diretórios e arquivos com o mesmo nome no
   diretório da operação.
   """,
   prog = "Pacotes",
   epilog = """Por uma questão de... preguiça, fiz
   tal programa que tem como objetivo facilitar
   o downlaod da mais atual versão do código, que
   sempre que terminado é subido para o GitHub. Ao
   invés de ficar entre pelo site, e indo diretamente
   no pacote toda vez, este pega tal, faz download
   e descompacta o mesmo, se no diretório onde já têm
   um, substituindo pelo mais novo.
    O modo como faz isso é seguir o link de um
   arquivo 'txt', que fica no diretório principal
   dos códigos de cada linguagem, sem tal, é impossível
   baixar tais, sequer listar-lôs.""",
   usage="%(prog)s [OPÇÃO] <NOME_DO_PKG>"
)

if __debug__:
   menu.print_help()

# conteúdo dos arquivos 'txt' com cabeçalhos/links.
grade = carrega()

# adicionando também versões minúsculas/maiúsculas
# para que se possa digitar de qualquer ordem.
def expansao(l) -> list:
   q = len(l)
   while q > 0:
      remocao = l.pop(0)
      if remocao.lower() in "python-rust":
         l.append(remocao.capitalize())
      else:
         minuscula = remocao.lower()
         maiusculas = remocao.upper()
         l.append(minuscula)
         l.append(maiusculas)
      ...
      l.append(remocao)
      q -= 1
   ...
   return l
...

menu.add_argument(
   "--lista", type=str,
   help="lista os pacotes disponíveis em cada linguagem.",
   metavar="LANG", nargs=1, default=None,
   choices = expansao(["python", "rust"])
)

# todos argumentos permitidos.
permicoes = list(grade["python"].keys())
permicoes.extend(list(grade["rust"].keys()))
permicoes.extend(["python", "rust"])
permicoes = expansao(permicoes)

menu.add_argument(
   "--obtem", type=str,
   help="""
   baixa um dos pacotes listados no atual diretório. Se
   não houver tal opção, então um erro será emitido. O
   primeiro argumento é a linguagem desejada, e o segundo
   é o pacote desejado.""",
   default=None, nargs=2, metavar=("LANG", "PKG"),
   choices = permicoes
)
menu.add_argument(
   "--atualiza", required=False,
   help = """atualiza todas versões/e
   última alteração dos pacotes.""",
   action="store_false"
)
argumentos = menu.parse_args()

if __debug__:
   print(argumentos)
   print(argumentos.lista)
...

# disparando o menu:
if argumentos.lista is not None:
   linguagem = argumentos.lista[0]
   listagemI(grade, linguagem)
elif argumentos.obtem is not None:
   # organizando argumentos da linha-de-comando.
   cabecalho = argumentos.obtem[1]
   linguagem = argumentos.obtem[0]
   if __debug__:
      print(
         "\n{barra}\nbaixando ... '{}' do {}\n{barra}\n"
         .format(
            cabecalho,
            linguagem.upper(),
            barra='*' * 50
         )
      )
   else:
      # carrega "mapa completo".
      mapa = carrega()
      # o mapa específico da linguagem.
      minimapa = mapa[linguagem.lower()]
      # baixa o download, e recebe tanto o
      # caminho com o conteúdo, como seus
      # metadados importantes.
      (caminho, tempo, versao) = baixa(cabecalho, minimapa)
      estrutura = arvore(caminho, True, GalhoTipo.FINO)
      link = minimapa[cabecalho]
      # gravando metadados no banco de dados...
      grava_pacote_registro(
         linguagem.lower(),
         cabecalho, link,
         versao, tempo
      )
      # movendo para este diretório.
      move(caminho, ".")
      # info da estrutura do pacote baixado.
      print(
         "{}\n\"{}\" foi baixado com sucesso."
         .format(estrutura, cabecalho),
         end="\n\n"
      )
   ...
elif argumentos.atualiza is not None:
   if __debug__:
      print("atualizando todo BD...")
   else:
      mapa = carrega()
      atualiza_bd(mapa)
   ...
else:
   print("nenhuma opção acionada!")


# pausa para ver os output por alguns segundos.
if platform == "win32":
   sleep(5.5)
