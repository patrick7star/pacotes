#!/usr/bin/python3 -O
"""
Programa em sí que baixa os pacotes
e arruma no atual diretório. Também
é possível selecionar o arquivo
específico a extrair.
"""

# deste programa:
#from gerenciador import carrega, mapa, listagem, carrega_rust
#from obtencao import baixa
from gerenciador import (carrega, listagem, CORE_PYTHON)

# biblioteca externa:
from python_utilitarios.utilitarios import arvore
GalhoTipo = arvore.GalhoTipo
arvore = arvore.arvore

# biblioteca padrão do Python:
from sys import argv, platform
from shutil import move
from time import sleep
from os.path import basename, exists, join
from shutil import rmtree
from os import chmod
from stat import S_IRWXU, S_IXGRP, S_IXOTH
from argparse import ArgumentParser

# colocando permisões:
try:
   chmod("pacotes.py", S_IRWXU | S_IXGRP | S_IXOTH)
except FileNotFoundError:
   caminho = join(CORE_PYTHON, "novo-pacotes/pacotes.py")
   chmod(caminho, S_IRWXU | S_IXGRP | S_IXOTH)
...

menu = ArgumentParser(
   description = """
   baixa pacotes Python ou Rust, diretos do GitHub,
   extraindo-os, e até substituindo os mesmos se já
   houver diretórios e arquivos com o mesmo nome no
   diretório da operação.
   """, 
   prog = "Pacotes",
   epilog = """Por uma questão de... preguiça, fiz
   tal programa que tem como objetivo facilitar
   o downlaod da mais atual versão do código, que
   sempre que terminado é subido para o GitHub. Ao
   invés de ficar entre pelo site, e indo diretamente
   no pacote toda vez, este pega tal, faz download
   e descompacta o mesmo, se no diretório onde já têm
   um, substituindo pelo mais novo.
    O modo como faz isso é seguir o link de um
   arquivo 'txt', que fica no diretório principal
   dos códigos de cada linguagem, sem tal, é impossível
   baixar tais, sequer listar-lôs.""",
   usage="%(prog)s [OPÇÃO] <NOME_DO_PKG>"
)

if __debug__:
   menu.print_help()

# conteúdo dos arquivos 'txt' com cabeçalhos/links.
grade = carrega()

# adicionando também versões minúsculas/maiúsculas
# para que se possa digitar de qualquer ordem.
def expansao(l) -> list:
   q = len(l)
   while q > 0:
      remocao = l.pop(0)
      if remocao.lower() in "python-rust":
         l.append(remocao.capitalize())
      else:
         minuscula = remocao.lower()
         maiusculas = remocao.upper()
         l.append(minuscula)
         l.append(maiusculas)
      ...
      l.append(remocao)
      q -= 1
   ...
   return l
...

menu.add_argument(
   "--lista", type=str,
   help="lista os pacotes disponíveis em cada linguagem.",
   metavar="LANG", nargs=1, default=None,
   choices = expansao(["python", "rust"])
)

# todos argumentos permitidos.
permicoes = list(grade["python"].keys())
permicoes.extend(list(grade["rust"].keys()))
permicoes.extend(["python", "rust"])
permicoes = expansao(permicoes)

menu.add_argument(
   "--obtem", type=str,
   help="""
   baixa um dos pacotes listados no atual diretório. Se
   não houver tal opção, então um erro será emitido. O
   primeiro argumento é a linguagem desejada, e o segundo
   é o pacote desejado.""", 
   default=None, nargs=2, metavar=("LANG", "PKG"),
   choices = permicoes
)
menu.add_argument("--atualiza", default=False,
   help = """atualiza todas versões/e 
   \rúltima alteração dos pacotes."""
)
argumentos = menu.parse_args()

if __debug__:
   print(argumentos)
   print(argumentos.lista)
...

# disparando o menu:
if argumentos.lista is not None:
   linguagem = argumentos.lista[0]
   listagem(grade, linguagem)
elif argumentos.obtem is not None:
   if __debug__:
      print(
         "\n{barra}\nbaixando ... '{}' do {}\n{barra}\n"
         .format(
            argumentos.obtem[1],
            argumentos.obtem[0].upper(),
            barra='*' * 50
         )
      )
   ...
else:
   print("nenhuma opção acionada!")


'''
# listando os pacotes ...
if __debug__:
   print("argumentos passados:", argv, end="\n\n")

# ativa versão para o Rust packages
# caso seja pedido.
versao_rust = False
if "--rust" in argv:
   indice = argv.index("--rust")
   argv.pop(indice)
   versao_rust = True
   assert versao_rust
   print("versão Rust acionada.")
   del carrega
else:
   assert not versao_rust
   if __debug__:
      print("versão Python acionada.")
...


if len(argv) == 1:
   if not versao_rust:
      listagem()
   else:
      carrega_rust()
else:
   if versao_rust:
      if __debug__:
         print("foi acionado?")
      carrega_rust()
   else:
      carrega()

   for arg in argv[1:]:
      caminho = baixa(arg, mapa)
      estrutura = arvore(caminho, True, GalhoTipo.FINO)

      # remove o diretório/arquivo se existente.
      nome_dir = basename(caminho)
      if exists(nome_dir):
         rmtree(nome_dir, ignore_errors=True)
         print("'{}' removido.".format(nome_dir))
      ...

      move(caminho, ".")
      print(
         "{}\n\"{}\" foi baixado com sucesso." 
         .format(estrutura, arg), 
         end="\n\n"
      )
   ...
...

'''
# pausa para ver os output por alguns segundos.
if platform == "win32":
   sleep(5.5)
